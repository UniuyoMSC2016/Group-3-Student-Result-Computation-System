package services;

import io.NFileIO;
import java.io.File;
import ui.G3Login;
import ui.MainUI;
import ui.MsgBox;

/**
 *
 * @author Ny
 */
public class User {
    
    NFileIO nFile = new NFileIO();
    static Object privList[] = null;
    
    public boolean logAdmin(String username, String pass, int logType){
        
        if(username.equalsIgnoreCase("Group3") && pass.equalsIgnoreCase("nei") )
        {
           return true;
        }else{
           return false;
        }
    }
    
   
    public boolean logTeacher(String username, String pass, int logType, File file){
        
        if( validateStaff( username, pass, file) )
        {
           return true;
        }else{
           return false;
        }
    }

    public boolean logStudent(String username, int logType){
        
        return true;
    }

    public boolean validateStaff(String user, String pass, File file)
    {
        String credential = user + pass;
        boolean ok = false;
        
        
       if(file.exists())
       {
          
           Object[] userList = nFile.readAppend(file);
           String[] users = new String[userList.length + 1];
           
           
           for(int c=0; c<userList.length;c++)
           {
               String uList[] = userList[c].toString().split("@");
               
               String userPass =  uList[2] + uList[3];
               privList = uList[4].split("&");
               
               if( credential.equalsIgnoreCase(userPass))
               {
                   ok = true;
                   break;
               }
               
           }
           
           
       }
       
       return ok;
       
    }
    
    
    public boolean hasPriviledge(String sclass)
    {
        boolean ok = false;
        if(privList != null && privList.length>0){
      
            for(int i=0; i<privList.length; i++){
                String eachPriv = privList[i].toString();
                if(sclass.contains(eachPriv)){
                    ok = true;
                    break;
                }
            }
        }
        
        return ok;
    }
    
    
    
    
}
