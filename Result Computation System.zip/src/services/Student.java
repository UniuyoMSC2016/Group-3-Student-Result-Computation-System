package services;

/**
 *
 * @author Ny
 */

import ui.MsgBox;
import ui.PrintPreview;
import io.NFileIO;
import ui.ECell;
import java.io.File;



public class Student {
    
    private String name, ID, sClass, address;
    private int age;
    NFileIO nFile = new NFileIO();
    
    public Student(String name, String ID, int age, String sClass, String address )
    {
        this.name = name; this.ID = ID; this.age = age; this.sClass = sClass; this.address = address;
    }
    
    public String getName(){ 
        return this.name;
    }
    
    public String getAge(){ 
        return this.name;
    }
    
    public String getStudClass(){ 
        return this.name;
    }
    public String getAddress(){ 
        return this.name;
    }
    
    @Override
    public String toString(){ 
        return this.name;
    }
    
    
    
    public void printResult(String[] results)
    {
        String[][] resultString = new String[1][results.length];
        
        for(int i=0; i<results.length; i++){
            
            resultString[0][i] =  results[i];
        }
        
        new PrintPreview(resultString , new String[]{"Name", "Test 1", "Test 2", "Test 3",  "Exams", "CA" ,"Total" , "Grade"} );
       
    }
    
    
    public ECell updateResult( File file, String studentID )
    {
        String result = "";
        ECell cell = null;
        
        if(file.exists()){
            
            result = nFile.getText( file);
        
            String[] eachRecord = result.split("@");
            
            for(int i=0; i<eachRecord.length-1; i++)
            {
               String[] cols = eachRecord[i].split("&");
               
              // MsgBox.showMessage(null, eachRecord.length +" :: " + cols.length + " :: " + cols[0]);
               
               String name = cols[0];
               
               if(name.contains(studentID))
               {
                   //MsgBox.showMessage(null, "Same");
                   cell = new ECell( cols[0] , cols[1], cols[2], cols[3], cols[4], cols[5], cols[6], cols[7], (i+1) );
                   break;
               }
               
             
            }
        
        }else{
            new MsgBox().showMessage(null,"Student Result", "This result does not exist!");
        }
        
        return cell;
    }
    
    
    
    
}
