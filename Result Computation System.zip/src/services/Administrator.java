package services;


import io.NFileIO;
import java.io.File;

/**
 *
 * @author Ny
 */

public class Administrator extends User {
    
    NFileIO nfile = new NFileIO();
    
    public boolean defineUsers(String name, String id, String username, String password, String priv, File file )
    {
        String content = name + "@" + id + "@" + username + "@" + password + "@" + priv + "\n" ;
        
               
        boolean ok = nfile.appendFile( file , content );
                
        return ok;
        
    }
    
    
}
