package services;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.io.File;

public class CreatePGMFolder
{
	JFileChooser fc = null;
	FileSystemView sv = null;
	File file = null;

	public String getDefaultDirectory()
	{
		fc = new JFileChooser();

		sv = fc.getFileSystemView();

		String documentFolder = (sv.getDefaultDirectory()).toString();

		return documentFolder;
	}

	

	public String makeDirectory(String folderName)
	{
		String dir = getDefaultDirectory() + File.separator + folderName;

		file = new File(dir);

		if(file.exists())
		{
			System.out.println(dir + " - already exist.");
		}
		else{
			boolean t = file.mkdir();

			if(t){
			System.out.println(dir + " - created successfully.");
			}
			else{
			System.out.println(dir + " - could not be created.");
			}
		}

		return dir;
	}


	public static void main(String g[])
	{
		new CreatePGMFolder().makeDirectory("Java_Analyser_Files");
	}

}//end of class
