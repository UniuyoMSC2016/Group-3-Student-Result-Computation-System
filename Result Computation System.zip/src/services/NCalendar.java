package services;
import java.util.*;

public class NCalendar
{
	static String time = "0:00:00";
	static String date = "00/00/0000";
        
        
        public static int getYear()
        {
            Calendar calendar = new GregorianCalendar();
            return calendar.get(Calendar.YEAR);

        }

	public static String getTime()
	{
		
	    Calendar calendar = new GregorianCalendar();
			
	    calendar.setTime( new Date() );

            String AM_PM = (calendar.get(Calendar.AM_PM)>0)? "PM" : "AM";

            time = calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND) + " " + AM_PM ;

            return time;
	}

	public static String getDate(String separator)
	{
		Calendar calendar = new GregorianCalendar();
			
		calendar.setTime( new Date() );

                date = calendar.get(Calendar.DAY_OF_MONTH) + separator + (calendar.get(Calendar.MONTH) + 1 ) + separator + calendar.get(Calendar.YEAR);
	
		return date;
	}

	public static long getTimeMillis()
	{
		Calendar calendar = new GregorianCalendar();
			
		calendar.setTime( new Date() );

		long t = calendar.getTimeInMillis();

		return t;
	}


	public static String getTimeSec()
	{
		
	    Calendar calendar = new GregorianCalendar();
			
	    calendar.setTime( new Date() );

            String AM_PM = (calendar.get(Calendar.AM_PM)>0)? "PM" : "AM";
           
            time = calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND) + "." + calendar.get(Calendar.MILLISECOND) + " " + AM_PM ;

            return time;
	}


        
}
