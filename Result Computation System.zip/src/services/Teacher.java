package services;


/**
 *
 * @author Ny
 */

import ui.MsgBox;
import ui.PrintPreview;
import io.NFileIO;
import ui.ECell;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.io.File;


public class Teacher {
    
    private String staffID, staffName, staffClass, rank;
    
    public Teacher(String staffID, String staffName, String staffClass, String rank )
    {
        this.staffID = staffID;
        this.staffName = staffName;
        this.staffClass = staffClass;
        this.rank = rank;
    }
    
    
    public double calculateCA(double test1, double test2, double test3)
    {
        double ca = test1 + test2 + test3;
        return ca;
    }
    
    
    public String computeGrade(double total)
    {
        String grade = "Fail";
        
        if(total>=0 && total<=45)
        {
            grade = "Fail";
        }else if(total>=46 && total<=49)
        {
            grade = "Weak Pass";
        }else if(total>=50 && total<=54)
        {
            grade = "Strong Pass";
        }else if(total>=55 && total<=59)
        {
            grade = "Fair";
        }else if(total>=60 && total<=64)
        {
            grade = "Merit";
        }else if(total>=65 && total<=69)
        {
            grade = "Credit";
        }else if(total>=70 && total<=74)
        {
            grade = "Good";
        }else if(total>=75 && total<=79)
        {
            grade = "Very Good";
        }else if(total>=80)
        {
            grade = "Excellent";
        }
        
        return grade;
    }
    
    
    public void printResult(ArrayList<ECell> results)
    {
        String[][] resultString = new String[results.size()][5];
        
        for(int i=0; i<results.size(); i++){
            
            ECell cell = results.get(i);
            resultString[i][0] = cell.getStudentName();
            resultString[i][1] = cell.getCA();
            resultString[i][2] = cell.getExams();
            resultString[i][3] = cell.getTotal();
            resultString[i][4] = cell.getGrade();
        }
        
        new PrintPreview(resultString , new String[]{"Name", "CA", "Exams" ,"Total" , "Grade"} );
    }
    
    NFileIO nfile = new NFileIO();
    public void saveResult( ArrayList<ECell> results, File file ){
        
        String result = "";
        
        for(int i=0; i<results.size(); i++){
            
            ECell cell = results.get(i);
            result += cell.getStudentName() + "&" + cell.getTest1() + "&" + cell.getTest2() + "&" + cell.getTest3() + "&" + cell.getExams()+ "&" + cell.getCA() + "&" + cell.getTotal() + "&" + cell.getGrade() + "@";
        }
        if( !result.trim().equals("") ){
            nfile.writeFile( result.getBytes(), file );
            new MsgBox().showMessage(null, "Save", "Result Saved!" );
        }
        
    }
    
    
    public ArrayList<ECell> updateResult(File file)
    {
        String result = nfile.getText( file);
        ArrayList<ECell> cells = new ArrayList<ECell>();
            
        if(file.exists()){
            String[] eachRecord = result.split("@");
            
            for(int i=0; i<eachRecord.length-1; i++)
            {
               String[] cols = eachRecord[i].split("&");
               ECell cell = new ECell( cols[0] , cols[1], cols[2], cols[3], cols[4], cols[5], cols[6], cols[7], (i+1) );
               cell.setPreferredSize( new Dimension(980, 30 ));
            
               cells.add(cell);
            }
        
        }else{
            new MsgBox().showMessage(null, "Result",  "This result is missing!");
        }
        
        return cells;
    }
    
    
    
    public boolean registerStudent(File file, String name, String ID, String age, String sclass , String addr)
    {
        boolean canAdd = true, added = false;
        
        Object[] sqList = nfile.readAppend(file); //student list
        
        String id = "";
        for(int c=0; c<sqList.length;c++)
        {
            String sList[] = sqList[c].toString().split("&");
           
            if(sList[1].equalsIgnoreCase(ID)){
                canAdd = false;
                break;
            }
        }
           
        
        if(canAdd){
            String str = name + "&" + ID + "&" + age + "&" + sclass + "&" + addr + "\n";
            added = nfile.appendFile( file, str);
        }else{
            new MsgBox().showMessage(null, "Add Student", "Student with id " + ID + " was already added!");
        }
        
        
        return (canAdd & added);
    }
    
    
}
