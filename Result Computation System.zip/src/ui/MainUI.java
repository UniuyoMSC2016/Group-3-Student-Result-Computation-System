package ui;

/**
 *
 * @author Ny
 */

import services.Teacher;
import ui.MsgBox;
import services.Student;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MainUI extends javax.swing.JPanel {

    JFrame frame = new JFrame("Main Menu");
    static Teacher teacher = new Teacher("","","","");
    static Student student = new Student("", "", 0 , "", ""); 
    
    ComputeResultUI computeUI = new ComputeResultUI() ;
    ExaminationResult resultUI = new ExaminationResult() ;
    AdminUI adminUI = new AdminUI() ;
        
    public MainUI( int logType, String username ) {
        
        initComponents();
        
        
        int x = Screen.width();
        int y = Screen.height();
        
        frame.setSize( x, y );
        frame.setDefaultCloseOperation(3);
        frame.add(this);
        frame.setUndecorated(true);
        
        jLabel10.setBounds(x-280, 5, 80, 60);
        jLabel8.setBounds(x-200, 5, 60, 60);
        jLabel2.setBounds(x-60, 10, 40, 50);
        jLabel9.setBounds(x-100, 35, 26, 5);
        jPanel1.setBounds( 0, (y/2-320/2),  225, 320); 
        
        
        jLabel3.addMouseListener( new G3FocusEvent() );
        jLabel4.addMouseListener( new G3FocusEvent() );
        jLabel5.addMouseListener( new G3FocusEvent() );
        
        jPanel2.setBounds(225, 100, x-240, y-150);
        jPanel3.setBounds( (x/2-670/2), 5, 670, 70);
        
        computeUI.setBounds(1, 1, jPanel2.getWidth()-2, jPanel2.getHeight()-2 );
        resultUI.setBounds(1, 25, jPanel2.getWidth()-2, jPanel2.getHeight()-27 );
        adminUI.setBounds(1, 25, jPanel2.getWidth()-2, jPanel2.getHeight()-27 );
        
        frame.setVisible(true);
        
        setUserTypeText(logType, username);
        
    }

    
    JLabel active = null;
    public void setActive( JLabel l )
    {
        l.setForeground(new Color(255,255,0));
    }
    
    public void hover( JLabel l , boolean entered )
    {
        if(entered){
            
           l.setForeground(new Color(255,255,255));
            
        }else{
            
            if(l != active){
                l.setForeground(new Color(0,255,255));
               
            }else{
               l.setForeground(new Color(255,255,0));
            }
        }   
    }
    
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        
        GradientPaint paint2 = new GradientPaint(0 , getHeight()-40 , new Color( 221,219,255 ) , 0 , getHeight() , new Color(117,197,240), false );
        g2.setPaint(paint2);
        g.fillRect(0,getHeight()-100, getWidth(), 100);
        
        for(int i=0; i<getWidth(); i+=3)
        {   g.drawImage(new ImageIcon(getClass().getResource("/raw/headerbg.png")).getImage(), i, 0, 3, 100, this);
        }
        
        g.setColor( new Color( 221,219,255 ) );
        for(int i=0; i<getWidth(); i+=5)
        {   g.drawLine(i, getHeight()-300, i, getHeight());  
        }
               
        g.drawImage(new ImageIcon(getClass().getResource("/raw/line2.png")).getImage(), 10, 50, 150, 1, this);
        g.drawImage(new ImageIcon(getClass().getResource("/raw/App-icon.png")).getImage(), 220, 5, 60, 60, this);
    }
    
    
    private class G3FocusEvent extends MouseAdapter{
        
        @Override
        public void mouseEntered(MouseEvent t)
        {
            JLabel l = (JLabel)t.getSource();
            hover( l , true );
        }
        
        @Override
        public void mouseExited(MouseEvent t2)
        {
            JLabel l = (JLabel)t2.getSource();
            hover( l , false );
        }
        
        
        @Override
        public void mouseClicked(MouseEvent t3)
        {
            active = (JLabel)t3.getSource();
            setActive(active);
            deactivate(jLabel3, jLabel4, jLabel5);
        }
    }
    
    
    public void deactivate(JLabel... labels){
        for(JLabel x:labels){
            if( x != active ){
               x.setForeground(new Color(0,255,255));
               
            }
        }
    }
    
    
    public static void main(String g[]){
        new MainUI( 0, "" );
    }
    
    
    int logType = -1;
    public void setUserTypeText(int type, String username){
        
        logType = type;
        
        if(type==0){
            jLabel1.setText("ADMIN :: " + username);
            
            jLabel8.setVisible(false);
            
            jPanel2.removeAll();
            jPanel2.add( adminUI );
            jPanel2.updateUI();
            
            
            active = jLabel5;
            setActive(active);
            deactivate(jLabel3, jLabel4, jLabel5);
        
        }else if(type==1){
            jLabel1.setText("TEACHER :: " + username);
            jLabel8.setVisible(true);
            
            jPanel2.removeAll();
            jPanel2.add( computeUI );
            jPanel2.updateUI();
            
            active = jLabel3;
            setActive(active);
            deactivate(jLabel3, jLabel4, jLabel5);
        
        
        }else{
            jLabel1.setText("STUDENT :: " + username );
            jLabel8.setVisible(false);
            
            jPanel2.removeAll();
            jPanel2.add( resultUI );
            jPanel2.updateUI();
            
            
            active = jLabel4;
            setActive(active);
            deactivate(jLabel3, jLabel4, jLabel5);
        
        
        }
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(222, 222, 222));
        setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("User Type");
        add(jLabel1);
        jLabel1.setBounds(0, 20, 180, 20);

        jPanel1.setBackground(new java.awt.Color(222, 222, 222));
        jPanel1.setLayout(null);

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/menu1.png"))); // NOI18N
        jLabel4.setText("Result");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel4.setOpaque(true);
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel4);
        jLabel4.setBounds(-50, 120, 280, 70);

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/menu1.png"))); // NOI18N
        jLabel5.setText("Define Users");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel5.setOpaque(true);
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel5);
        jLabel5.setBounds(-50, 250, 280, 70);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/menu1.png"))); // NOI18N
        jLabel3.setText("Compute Grade");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel3.setOpaque(true);
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel3);
        jLabel3.setBounds(-50, 0, 280, 70);

        add(jPanel1);
        jPanel1.setBounds(0, 120, 225, 320);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 51));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/close2.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        add(jLabel2);
        jLabel2.setBounds(970, 20, 40, 30);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);
        add(jPanel2);
        jPanel2.setBounds(230, 150, 530, 270);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setOpaque(false);
        jPanel3.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 40)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 91, 158));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Students Result Computation System");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(0, 0, 650, 40);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Version 1.0");
        jPanel3.add(jLabel7);
        jLabel7.setBounds(20, 40, 130, 30);

        add(jPanel3);
        jPanel3.setBounds(140, 10, 670, 70);

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/studAdd.png"))); // NOI18N
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        add(jLabel8);
        jLabel8.setBounds(840, 20, 60, 40);

        jLabel9.setBackground(new java.awt.Color(255, 102, 0));
        jLabel9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 102, 0), 1, true));
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel9.setOpaque(true);
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        add(jLabel9);
        jLabel9.setBounds(920, 35, 26, 5);

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Sign Out");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });
        add(jLabel10);
        jLabel10.setBounds(790, 10, 80, 50);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        System.exit(1);
    }//GEN-LAST:event_jLabel2MouseClicked

    
    
    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
       //add student
       
       if( logType == 1 ){
           ComputeResultUI.showAddStudent();
       }else{ new MsgBox().showMessage(null,"Priviledge", "You do not have the priviledge to access this!"); }
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        //Teacher Tab
        if( logType == 1 ){
            
            jLabel8.setVisible(true);
            
            jPanel2.removeAll();
            jPanel2.add( computeUI );
            jPanel2.updateUI();
        }else{ new MsgBox().showMessage(null, "Priviledge",  "You do not have the priviledge to access this tab!"); }
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        // Student Tab
        if( logType ==0 || logType == 1 || logType==2){
            
            jLabel8.setVisible(false);
            
            jPanel2.removeAll();
            jPanel2.add( resultUI );
            jPanel2.updateUI();
        }
        
        
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        frame.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // Admin Tab
        if( logType == 0 ){
            
            jLabel8.setVisible(false);
            
            jPanel2.removeAll();
            jPanel2.add( adminUI );
            jPanel2.updateUI();
        }else{ new MsgBox().showMessage(null, "Priviledge",  "You do not have the priviledge to access this tab!"); }
        
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        this.frame.dispose();
        new G3Login();
    }//GEN-LAST:event_jLabel10MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
