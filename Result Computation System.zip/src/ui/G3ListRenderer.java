package ui;


/**
 *
 * @author Ny
 */
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;

public class G3ListRenderer  extends JPanel implements ListCellRenderer<Object>{
    
    JLabel display = new JLabel();
    
    public G3ListRenderer() 
    {
        setOpaque(false);
        setLayout(null);
        display.setBounds(-1,0,480, 30);
        display.setOpaque(true);
        display.setFont( new Font("Tempus Sans ITC" , 1 , 18) );
        add(display);
    }
    
    public Component getListCellRendererComponent(JList<?> list,Object value, int index,boolean isSelected,boolean cellHasFocus) 
    {
        display.setText(" " + value.toString());
        
        Color background;
        Color foreground;
        Border border;
       
        Color backgroundNSelected = new Color(250, 250, 250);
        Color foregroundNSelected = Color.black;
        
        //[255,153,0]
        //Color backgroundSelected = new Color(0, 153, 153);
        Color backgroundSelected = new Color( 245, 245, 245);
        Color foregroundSelected = Color.black;
        
        // check if this cell represents the current DnD drop location
        JList.DropLocation dropLocation = list.getDropLocation();
        if (dropLocation != null && !dropLocation.isInsert() && dropLocation.getIndex() == index) 
        {
             background = foregroundSelected;
             foreground = foregroundSelected;
             border = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
         // check if this cell is selected
        } else if (isSelected) {
             background = backgroundSelected;
             foreground = foregroundSelected;
             border = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
         // unselected, and not the DnD drop location
        } else {
             background = backgroundNSelected;
             foreground = foregroundNSelected;
             border = null;
        };

        display.setBackground(background);
        display.setForeground(foreground);
        display.setBorder(border);

        return this;
    }
    
}
