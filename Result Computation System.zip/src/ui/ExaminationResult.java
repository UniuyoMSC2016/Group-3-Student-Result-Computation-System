package ui;

/**
 *
 * @author Ny
 */

import services.NCalendar;
import services.Teacher;
import ui.MainUI;
import ui.MsgBox;
import ui.AddStudentDialog;
import io.NFileIO;
import ui.ECell;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;


public class ExaminationResult extends javax.swing.JPanel {

    Teacher teacher = new Teacher("", "", "", "");
    
    static AddStudentDialog add = new AddStudentDialog();
    NFileIO nFile = new NFileIO();
    
    SList studList = new SList();
    
    public ExaminationResult() {
        initComponents();
        
        jPanel2.setBounds(Screen.x(10), Screen.y(2), 840, 50 );
        jPanel1.setBounds(Screen.x(10), Screen.y(10), 840, 50 );
        
        jPanel3.setBounds(Screen.x(10), Screen.y(22), 810, 170 );
        add(jPanel3);
        
        jLabel3.addMouseListener(new G3FocusEvent());
        jLabel4.addMouseListener(new G3FocusEvent());
        jLabel5.addMouseListener(new G3FocusEvent());
        jLabel6.addMouseListener(new G3FocusEvent());
        jLabel7.addMouseListener(new G3FocusEvent());
        
    }
    
    
    
    public static void showAddStudent()
    {
        String fileName = NCalendar.getYear() + "_" + jComboBox1.getSelectedItem() + "_" + jComboBox2.getSelectedItem() + "_" + jComboBox3.getSelectedItem();
        String desc = NCalendar.getYear() + " " + jComboBox1.getSelectedItem() + "-" + jComboBox2.getSelectedItem() + " " + jComboBox3.getSelectedItem() + " STUDENTS";
        String studClass = jComboBox1.getSelectedItem() + "-" + jComboBox2.getSelectedItem();
         add.showDialog( fileName, desc, studClass );
    }
    
    private class G3FocusEvent extends MouseAdapter{
        
       
        @Override
        public void mouseClicked(MouseEvent t3)
        {
            JLabel l = (JLabel)t3.getSource();
           
        }
        
        
    }
    
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jComboBox2 = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 51));
        jLabel1.setText("SELECT CLASS");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 10, 120, 25);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "JSS1", "JSS2", "JSS3", "SS1", "SS2", "SS3" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox1);
        jComboBox1.setBounds(130, 10, 110, 26);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }));
        jPanel1.add(jComboBox2);
        jComboBox2.setBounds(240, 10, 60, 26);

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 51));
        jLabel2.setText("SELECT SUBJECT");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(380, 10, 140, 25);

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MATHEMATICS", "ENGLISH", "PHYSIC", "CHEMISTRY", "BIOLOGY", "ECONOMICS", "INTER-SCIENCE", "COMMERCE", "BUSINESS STUDIES", "GEOGRAPHY", "LITERATURE", "ACCOUNTING", "GOVERNMENT", "FINE ART" }));
        jPanel1.add(jComboBox3);
        jComboBox3.setBounds(520, 10, 170, 26);

        jSeparator1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.add(jSeparator1);
        jSeparator1.setBounds(0, 40, 800, 10);

        jLabel5.setBackground(new java.awt.Color(255, 153, 51));
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("VIEW");
        jLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 51, 51)));
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.setOpaque(true);
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel5MouseExited(evt);
            }
        });
        jPanel1.add(jLabel5);
        jLabel5.setBounds(710, 10, 90, 25);

        add(jPanel1);
        jPanel1.setBounds(20, 70, 840, 50);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 51));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/clear.png"))); // NOI18N
        jLabel3.setText("Clear");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel3);
        jLabel3.setBounds(580, 0, 90, 40);

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 153, 51));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/print.png"))); // NOI18N
        jLabel4.setText("Print");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel4);
        jLabel4.setBounds(710, 0, 100, 40);

        jLabel9.setBackground(new java.awt.Color(255, 153, 51));
        jLabel9.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("ENTER STUDENT ID:");
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel9.setOpaque(true);
        jPanel2.add(jLabel9);
        jLabel9.setBounds(0, 10, 200, 30);

        jTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jTextField1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jPanel2.add(jTextField1);
        jTextField1.setBounds(200, 10, 260, 30);

        add(jPanel2);
        jPanel2.setBounds(20, 10, 820, 50);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jPanel3.setLayout(null);

        jLabel6.setBackground(new java.awt.Color(245, 245, 245));
        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 51));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel6.setOpaque(true);
        jPanel3.add(jLabel6);
        jLabel6.setBounds(10, 80, 150, 30);

        jLabel7.setBackground(new java.awt.Color(245, 245, 245));
        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 51));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel7.setOpaque(true);
        jPanel3.add(jLabel7);
        jLabel7.setBounds(160, 80, 70, 30);

        jLabel8.setBackground(new java.awt.Color(245, 245, 245));
        jLabel8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 51));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel8.setOpaque(true);
        jPanel3.add(jLabel8);
        jLabel8.setBounds(230, 80, 70, 30);

        jLabel10.setBackground(new java.awt.Color(245, 245, 245));
        jLabel10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 51));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel10.setOpaque(true);
        jPanel3.add(jLabel10);
        jLabel10.setBounds(300, 80, 60, 30);

        jLabel11.setBackground(new java.awt.Color(245, 245, 245));
        jLabel11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 51, 51));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel11.setOpaque(true);
        jPanel3.add(jLabel11);
        jLabel11.setBounds(360, 80, 110, 30);

        jLabel12.setBackground(new java.awt.Color(245, 245, 245));
        jLabel12.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 51, 51));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel12.setOpaque(true);
        jPanel3.add(jLabel12);
        jLabel12.setBounds(470, 80, 70, 30);

        jLabel13.setBackground(new java.awt.Color(245, 245, 245));
        jLabel13.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 51, 51));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel13.setOpaque(true);
        jPanel3.add(jLabel13);
        jLabel13.setBounds(540, 80, 130, 30);

        jLabel14.setBackground(new java.awt.Color(245, 245, 245));
        jLabel14.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 51, 51));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel14.setOpaque(true);
        jPanel3.add(jLabel14);
        jLabel14.setBounds(670, 80, 130, 30);

        jLabel15.setBackground(new java.awt.Color(245, 245, 245));
        jLabel15.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 153, 51));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("STUDENT NAME");
        jLabel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel15.setOpaque(true);
        jPanel3.add(jLabel15);
        jLabel15.setBounds(10, 40, 150, 30);

        jLabel16.setBackground(new java.awt.Color(245, 245, 245));
        jLabel16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 153, 51));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("TEST 1");
        jLabel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel16.setOpaque(true);
        jPanel3.add(jLabel16);
        jLabel16.setBounds(160, 40, 70, 30);

        jLabel17.setBackground(new java.awt.Color(245, 245, 245));
        jLabel17.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 153, 51));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("TEST 2");
        jLabel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel17.setOpaque(true);
        jPanel3.add(jLabel17);
        jLabel17.setBounds(230, 40, 70, 30);

        jLabel18.setBackground(new java.awt.Color(245, 245, 245));
        jLabel18.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 153, 51));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("TEST 3");
        jLabel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel18.setOpaque(true);
        jPanel3.add(jLabel18);
        jLabel18.setBounds(300, 40, 60, 30);

        jLabel19.setBackground(new java.awt.Color(245, 245, 245));
        jLabel19.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 153, 51));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("EXAMS");
        jLabel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel19.setOpaque(true);
        jPanel3.add(jLabel19);
        jLabel19.setBounds(360, 40, 110, 30);

        jLabel20.setBackground(new java.awt.Color(245, 245, 245));
        jLabel20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 153, 51));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("CA");
        jLabel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel20.setOpaque(true);
        jPanel3.add(jLabel20);
        jLabel20.setBounds(470, 40, 70, 30);

        jLabel21.setBackground(new java.awt.Color(245, 245, 245));
        jLabel21.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 153, 51));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("TOTAL SCORE");
        jLabel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel21.setOpaque(true);
        jPanel3.add(jLabel21);
        jLabel21.setBounds(540, 40, 130, 30);

        jLabel22.setBackground(new java.awt.Color(245, 245, 245));
        jLabel22.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 153, 51));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("GRADE");
        jLabel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel22.setOpaque(true);
        jPanel3.add(jLabel22);
        jLabel22.setBounds(670, 40, 130, 30);

        add(jPanel3);
        jPanel3.setBounds(20, 170, 810, 170);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        clearCells();
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        
        String name = jLabel6.getText();
        String t1 = jLabel7.getText();
        String t2 = jLabel8.getText();
        String t3 = jLabel10.getText();
        String exm = jLabel11.getText();
        String ca = jLabel12.getText();
        String total = jLabel13.getText();
        String grade = jLabel14.getText();
         
        if(validate( name, t1, t2, t3, exm, ca, total, grade ) ){
            String result[] = { name, t1, t2, t3, exm, ca, total, grade  };
            MainUI.student.printResult( result );
        }else{
            new MsgBox().showMessage(null,"Examination",  "Some fields are missing!");
        }
        
        
    }//GEN-LAST:event_jLabel4MouseClicked

    
    public boolean validate(String... items)
    {
        for(String x: items){
            if(x.trim().equals("")){
                return false;
            }
        }
        return true;
    }
    
    ResultFileList resultFileList = new ResultFileList();
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    
    ArrayList<String> studentList = new ArrayList<String>();
    
    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
       
        String fileName = NCalendar.getYear() + "_" + jComboBox1.getSelectedItem() + "_" + jComboBox2.getSelectedItem() + "_" + jComboBox3.getSelectedItem();
        
        String directory = G3Splash.resultDir;
        
        File file = new File( directory + fileName + ".rsl"  );
        
        String stdID = "";
        try{
            stdID = jTextField1.getText();
        }catch(Exception e){}
        
        ECell cell = MainUI.student.updateResult( file, stdID );
        if(cell !=null){
            jLabel6.setText(cell.getStudentName());
            jLabel7.setText(cell.getTest1());
            jLabel8.setText(cell.getTest2());
            jLabel10.setText(cell.getTest3());
            jLabel11.setText(cell.getExams());
            jLabel12.setText(cell.getCA());
            jLabel13.setText(cell.getTotal());
            jLabel14.setText(cell.getGrade());
        }else{ System.out.println(file.getPath()); new MsgBox().showMessage(null, "Examination", "This student's result is not found for current class and subject!"); }
        
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseExited

    
    public void clearCells()
    {
        jLabel6.setText("");
        jLabel7.setText("");
        jLabel8.setText("");
        jLabel10.setText("");
        jLabel11.setText("");
        jLabel12.setText("");
        jLabel13.setText("");
        jLabel14.setText("");
       
    }
    
    
    static ArrayList<ECell> resultArray = new ArrayList<ECell>();
    
    public void addCells( Object[] students , int elementLength, int spacing )
    {
        jPanel3.removeAll();
        resultArray.clear();
        
        int totalSize = students.length * elementLength + students.length * spacing;
        jLabel8.setText(students.length+"");
        
        for(int i=0; i<students.length; i++){
            
            ECell cell = new ECell( students[i].toString() , (i+1) );
            cell.setPreferredSize( new Dimension(980, elementLength));
            resultArray.add(cell);
            jPanel3.add(cell);
        }
        
        jPanel3.setPreferredSize( new Dimension( 980, totalSize) );
        jPanel3.updateUI();
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JComboBox jComboBox1;
    private static javax.swing.JComboBox jComboBox2;
    private static javax.swing.JComboBox jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private static javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
