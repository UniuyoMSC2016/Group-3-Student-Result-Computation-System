package ui;

/**
 *
 * @author Ny
 */

import services.Administrator;
import services.Teacher;
import ui.MsgBox;
import ui.AddStudentDialog;
import io.NFileIO;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import services.Student;


public class AdminUI extends javax.swing.JPanel {

    Teacher teacher = new Teacher("", "", "", "");
    static Student student = new Student("", "", 0 , "", ""); 
    
    static AddStudentDialog add = new AddStudentDialog();
    NFileIO nFile = new NFileIO();
    
    SList studList = new SList();
    Administrator admin = new Administrator();
    
      
    
    
    public AdminUI() {
        initComponents();
        
        jPanel2.setBounds(Screen.x(10), Screen.y(3), 800, 50 );
        
        jLabel1.setBounds(Screen.x(10), 90, 160, 50 );
        jLabel5.setBounds(Screen.x(23), 90, 160, 50 );
        jLabel2.setBounds(Screen.x(38), 90, 180, 50 );
        jPanel3.setBounds(Screen.x(10), Screen.y(22), 800, 340 );
        add(jPanel3);
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setLayout(null);

        jLabel24.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(51, 51, 51));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("ADMIN :: USER DEFINITION");
        jPanel2.add(jLabel24);
        jLabel24.setBounds(0, 0, 770, 50);

        add(jPanel2);
        jPanel2.setBounds(20, 20, 800, 50);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jPanel3.setLayout(null);

        jLabel16.setBackground(new java.awt.Color(245, 245, 245));
        jLabel16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 153, 51));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("TEACHERS NAME");
        jLabel16.setOpaque(true);
        jPanel3.add(jLabel16);
        jLabel16.setBounds(80, 20, 200, 30);

        jLabel17.setBackground(new java.awt.Color(245, 245, 245));
        jLabel17.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 153, 51));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("ACCESS LEVEL");
        jLabel17.setOpaque(true);
        jPanel3.add(jLabel17);
        jLabel17.setBounds(80, 160, 160, 30);

        jLabel19.setBackground(new java.awt.Color(245, 245, 245));
        jLabel19.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 153, 51));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("PASSWORD");
        jLabel19.setOpaque(true);
        jPanel3.add(jLabel19);
        jLabel19.setBounds(80, 290, 190, 30);

        jLabel21.setBackground(new java.awt.Color(245, 245, 245));
        jLabel21.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 153, 51));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("STAFF'S ID");
        jLabel21.setOpaque(true);
        jPanel3.add(jLabel21);
        jLabel21.setBounds(80, 90, 130, 30);

        jLabel23.setBackground(new java.awt.Color(245, 245, 245));
        jLabel23.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 153, 51));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("USENAME");
        jLabel23.setOpaque(true);
        jPanel3.add(jLabel23);
        jLabel23.setBounds(80, 230, 240, 30);

        jTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jTextField1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField1.setCaretColor(new java.awt.Color(255, 153, 0));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField1);
        jTextField1.setBounds(320, 20, 390, 30);

        jTextField2.setBackground(new java.awt.Color(255, 255, 255));
        jTextField2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(0, 0, 0));
        jTextField2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField2.setCaretColor(new java.awt.Color(255, 153, 0));
        jPanel3.add(jTextField2);
        jTextField2.setBounds(260, 90, 450, 30);

        jTextField3.setBackground(new java.awt.Color(255, 255, 255));
        jTextField3.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField3.setForeground(new java.awt.Color(0, 0, 0));
        jTextField3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField3.setCaretColor(new java.awt.Color(255, 153, 0));
        jPanel3.add(jTextField3);
        jTextField3.setBounds(360, 230, 350, 30);

        jTextField4.setBackground(new java.awt.Color(255, 255, 255));
        jTextField4.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField4.setForeground(new java.awt.Color(0, 0, 0));
        jTextField4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField4.setCaretColor(new java.awt.Color(255, 153, 0));
        jPanel3.add(jTextField4);
        jTextField4.setBounds(310, 290, 400, 30);

        jCheckBox1.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox1.setForeground(new java.awt.Color(255, 153, 51));
        jCheckBox1.setText("JSS1");
        jCheckBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jPanel3.add(jCheckBox1);
        jCheckBox1.setBounds(280, 160, 60, 30);

        jCheckBox2.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox2.setForeground(new java.awt.Color(255, 153, 51));
        jCheckBox2.setText("JSS2");
        jCheckBox2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jPanel3.add(jCheckBox2);
        jCheckBox2.setBounds(350, 160, 60, 30);

        jCheckBox3.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox3.setForeground(new java.awt.Color(255, 153, 51));
        jCheckBox3.setText("JSS3");
        jCheckBox3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jPanel3.add(jCheckBox3);
        jCheckBox3.setBounds(420, 160, 70, 30);

        jCheckBox4.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox4.setForeground(new java.awt.Color(255, 153, 51));
        jCheckBox4.setText("SS1");
        jCheckBox4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jPanel3.add(jCheckBox4);
        jCheckBox4.setBounds(500, 160, 60, 30);

        jCheckBox5.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox5.setForeground(new java.awt.Color(255, 153, 51));
        jCheckBox5.setText("SS2");
        jCheckBox5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jPanel3.add(jCheckBox5);
        jCheckBox5.setBounds(570, 160, 60, 30);

        jCheckBox6.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox6.setForeground(new java.awt.Color(255, 153, 51));
        jCheckBox6.setText("SS3");
        jCheckBox6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });
        jPanel3.add(jCheckBox6);
        jCheckBox6.setBounds(640, 160, 70, 30);

        add(jPanel3);
        jPanel3.setBounds(20, 150, 800, 340);

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setForeground(new java.awt.Color(255, 153, 51));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/save.png"))); // NOI18N
        jLabel5.setText("SAVE");
        jLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.setOpaque(true);
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        add(jLabel5);
        jLabel5.setBounds(300, 90, 160, 50);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setForeground(new java.awt.Color(255, 153, 51));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/clear.png"))); // NOI18N
        jLabel1.setText("CLEAR");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.setOpaque(true);
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        add(jLabel1);
        jLabel1.setBounds(130, 90, 150, 50);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setForeground(new java.awt.Color(255, 153, 51));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/viewList.png"))); // NOI18N
        jLabel2.setText("VIEW USERS");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.setOpaque(true);
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        add(jLabel2);
        jLabel2.setBounds(480, 90, 180, 50);
    }// </editor-fold>//GEN-END:initComponents

    
    public boolean validate(String... items)
    {
        for(String x: items){
            if(x.trim().equals("")){
                return false;
            }
        }
        return true;
    }
    
    ResultFileList resultFileList = new ResultFileList();
    
    ArrayList<String> studentList = new ArrayList<String>();
    
    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
       
        String name = jTextField1.getText();
        String id = jTextField2.getText();
        String username = jTextField3.getText();
        String password = jTextField4.getText();
        
        String priv = getPriviledges(jCheckBox1, jCheckBox2, jCheckBox3, jCheckBox4, jCheckBox5, jCheckBox6 );
                
        if(validate(name, id, username, password, priv ) ){
            
            
            if( !userExists( name, id, password ))
            {
                String fileName = "sysk";
                File file = new File( G3Splash.keyDir + fileName + ".key" );
    
                boolean ok = admin.defineUsers( name, id, username, password, priv , file);
                if(ok){
                    clear();
                    new MsgBox().showMessage(null, "User Definition",  "User defined!" );
                }
            
            }else{ new MsgBox().showMessage(null, "User Registration",  "This user has already been registered!" ); }
            
        }else{
            new MsgBox().showMessage(null, "User Registration", "Please fill out the form!" );
        }
        
    }//GEN-LAST:event_jLabel5MouseClicked

    
    public String getPriviledges(JCheckBox... priv)
    {
        String pr = "";
        for(JCheckBox bx : priv){
            if(bx.isSelected()){
                pr += bx.getText() + "&";
            }
        }
        
        if(pr.length()>1){ pr = pr.substring( 0 , pr.length()-1 ); }
        
        return pr;
    }
    
    
    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_jLabel1MouseClicked

    UList uListDialog = new UList();
    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
      
        String fileName = "sysk";
        
        File file = new File( G3Splash.keyDir + fileName + ".key" );
        
        
       if(file.exists())
       {
          
           Object[] userList = nFile.readAppend(file);
           String[] users = new String[userList.length];
           
           
           for(int c=0; c<userList.length;c++)
           {
               String uList[] = userList[c].toString().split("@");
               
               String rw = uList[0] + " | " + uList[1] + " | " + uList[2] + " | " + uList[3] + " | " + uList[4];
               users[c] = rw;
               
           }
           
           uListDialog.showList( users );
       }
           
    }//GEN-LAST:event_jLabel2MouseClicked

    
    
    
    public boolean userExists(String name, String id, String password )
    {
        boolean ok = false;
        String fileName = "sysk";
        
        File file = new File( G3Splash.keyDir + fileName + ".key" );
        
       if(file.exists())
       {
          
           Object[] userList = nFile.readAppend(file);
           String[] users = new String[userList.length + 1];
           
           
           for(int c=0; c<userList.length;c++)
           {
               String uList[] = userList[c].toString().split("@");
               
               if( uList[0].equalsIgnoreCase(name) || uList[1].equalsIgnoreCase(id) || uList[3].equalsIgnoreCase(password)  )
               {
                   ok = true;
                   break;
               }
               
           }
       }
       
       return ok;
       
    }
    
    
    
    public void clear()
    {
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private static javax.swing.JPanel jPanel3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
