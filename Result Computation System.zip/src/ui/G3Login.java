package ui;

/**
 *
 * @author Ny
 */

import ui.Screen;
import ui.MainUI;
import ui.MsgBox;
import io.NFileIO;
import services.User;
import javax.swing.*;
import java.awt.*;
import java.io.File;

public class G3Login extends javax.swing.JPanel {

    
    JFrame frame = new JFrame("Cr Login");
    User user = new User();
    //MsgBox box = new MsgBox();
    
    public G3Login() {
        initComponents();
        
        int x = Screen.width();
        int y = Screen.height();
        
        jPanel3.setBounds(20, Screen.y(36),360, 210);
      
        jPanel2.setBounds(0, y-130,400, 100);
        jLabel3.setBounds(0, y-132,400, 2);
          
        frame.add(this);
        frame.setUndecorated(true);
        frame.setLocation(0,0);
	frame.setSize(400,y);
	frame.setVisible(true);   
    }

       
    public static void main(String g[])
    {
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            	if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        
        new G3Login();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel11 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255), 2));
        setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 51, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("SRCS");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 10, 230, 50);

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("X");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel4);
        jLabel4.setBounds(350, 30, 34, 30);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 255, 153));
        jLabel10.setText("version 1.1");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(20, 50, 100, 30);

        add(jPanel1);
        jPanel1.setBounds(0, 0, 400, 100);

        jLabel2.setBackground(new java.awt.Color(255, 153, 0));
        jLabel2.setOpaque(true);
        add(jLabel2);
        jLabel2.setBounds(0, 100, 400, 15);

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setLayout(null);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Designed and Developed by");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(20, 20, 360, 20);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("2015/2016 Uniuyo MSC Group 3");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(20, 60, 360, 20);

        add(jPanel2);
        jPanel2.setBounds(0, 402, 400, 100);

        jLabel3.setBackground(new java.awt.Color(255, 153, 0));
        jLabel3.setOpaque(true);
        add(jLabel3);
        jLabel3.setBounds(0, 400, 400, 2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 204, 102));
        jLabel5.setText("USERNAME:");
        jPanel3.add(jLabel5);
        jLabel5.setBounds(30, 70, 100, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 204, 102));
        jLabel6.setText("PASSWORD:");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(30, 120, 100, 30);

        jLabel7.setBackground(new java.awt.Color(255, 153, 0));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("LOGIN");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.setOpaque(true);
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel7);
        jLabel7.setBounds(230, 180, 100, 30);

        jTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField1);
        jTextField1.setBounds(130, 70, 200, 30);

        jPasswordField1.setBackground(new java.awt.Color(255, 255, 255));
        jPasswordField1.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        jPasswordField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel3.add(jPasswordField1);
        jPasswordField1.setBounds(130, 120, 200, 30);

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 204, 102));
        jLabel11.setText("LOGIN TYPE:");
        jPanel3.add(jLabel11);
        jLabel11.setBounds(30, 16, 100, 40);

        jComboBox1.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Admin", "Staff", "Student" }));
        jComboBox1.setBorder(null);
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox1);
        jComboBox1.setBounds(130, 20, 200, 30);

        add(jPanel3);
        jPanel3.setBounds(20, 150, 360, 210);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        System.exit(1);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // login        
        String username = jTextField1.getText();
        String pass = jPasswordField1.getText();
        int logType = jComboBox1.getSelectedIndex();
            
        if( logType == 0 )
        {
            boolean response = user.logAdmin(username, pass, logType );
            if(response){ new MainUI( logType, username ); frame.setVisible(false); }else{ new MsgBox().showMessage(frame, "Login", "Incorrect username and or password"); }
            
        }else if(  logType == 1  ){
            
        String fileName = "sysk";
        File file = new File( G3Splash.keyDir + fileName + ".key" );
        
        boolean response = user.logTeacher(username, pass, logType, file);
        if(response){ new MainUI( logType, username ); frame.setVisible(false); }else{ new MsgBox().showMessage(frame, "Login", "Incorrect username and or password"); }
        }
        else{
            frame.setVisible(false);
            new MainUI( logType, "" );
            user.logStudent( username , logType );
        }
        
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        int index =  jComboBox1.getSelectedIndex();
        if(index == 0){
            showLog( true );
        }else if(index == 1){
            showLog( true );
        }else{
            showLog( false );
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    
    public void showLog(boolean b){
        jLabel5.setVisible(b);
        jLabel6.setVisible(b);
        
        jTextField1.setVisible(b);
        jPasswordField1.setVisible(b);
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
