package ui;

/**
 *
 * @author Ny
 */

import services.NCalendar;
import services.Teacher;
import ui.MsgBox;
import ui.AddStudentDialog;
import io.NFileIO;
import ui.ECell;
import services.Student;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import services.User;


public class ComputeResultUI extends javax.swing.JPanel {

    /**
     * Creates new form ComputeResultUI
     */
    Teacher teacher = new Teacher("", "", "", "");
    static AddStudentDialog add = new AddStudentDialog();
    NFileIO nFile = new NFileIO();
    User user = new User();
    SList studList = new SList();
    
    public ComputeResultUI() {
        initComponents();
        
        jPanel2.setBounds(Screen.x(10), Screen.y(2), 850, 50 );
        jPanel1.setBounds(Screen.x(10), Screen.y(10), 850, 50 );
        
        
        RHeader header = new RHeader();
        header.setBounds(Screen.x(5), Screen.y(18), 1000, 40 );
        add(header);
        
        JScrollPane scr = new JScrollPane(jPanel3);
        scr.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scr.setBounds(Screen.x(5), Screen.y(23), 1000, Screen.height()-350 );
        scr.setBorder(null);
        add(scr);
        
        jLabel3.addMouseListener(new G3FocusEvent());
        jLabel4.addMouseListener(new G3FocusEvent());
        jLabel5.addMouseListener(new G3FocusEvent());
        jLabel6.addMouseListener(new G3FocusEvent());
        jLabel7.addMouseListener(new G3FocusEvent());
    }
    
    
    public static void showAddStudent()
    {
        String fileName = NCalendar.getYear() + "_" + jComboBox1.getSelectedItem() + "_" + jComboBox2.getSelectedItem();
        String desc = NCalendar.getYear() + " " + jComboBox1.getSelectedItem() + "-" + jComboBox2.getSelectedItem() + " STUDENTS";
        String studClass = jComboBox1.getSelectedItem() + "-" + jComboBox2.getSelectedItem();
        add.showDialog( fileName, desc, studClass );
    }
    
    private class G3FocusEvent extends MouseAdapter{
        
        @Override
        public void mouseClicked(MouseEvent t3)
        {
            JLabel l = (JLabel)t3.getSource();
           
        }
    }
    
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jComboBox2 = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 51));
        jLabel1.setText("SELECT CLASS");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 10, 120, 25);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "JSS1", "JSS2", "JSS3", "SS1", "SS2", "SS3" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox1);
        jComboBox1.setBounds(130, 10, 110, 26);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }));
        jPanel1.add(jComboBox2);
        jComboBox2.setBounds(240, 10, 60, 26);

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 51));
        jLabel2.setText("SELECT SUBJECT");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(380, 10, 140, 25);

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MATHEMATICS", "ENGLISH", "PHYSIC", "CHEMISTRY", "BIOLOGY", "ECONOMICS", "INTER-SCIENCE", "COMMERCE", "BUSINESS STUDIES", "GEOGRAPHY", "LITERATURE", "ACCOUNTING", "GOVERNMENT", "FINE ART" }));
        jPanel1.add(jComboBox3);
        jComboBox3.setBounds(520, 10, 220, 26);

        jSeparator1.setBackground(new java.awt.Color(255, 153, 51));
        jPanel1.add(jSeparator1);
        jSeparator1.setBounds(10, 40, 820, 10);

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jPanel1.add(jLabel8);
        jLabel8.setBounds(750, 10, 80, 25);

        add(jPanel1);
        jPanel1.setBounds(10, 70, 850, 50);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 51));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/clear.png"))); // NOI18N
        jLabel3.setText("Clear");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel3);
        jLabel3.setBounds(0, 0, 90, 40);

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 153, 51));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/print.png"))); // NOI18N
        jLabel4.setText("Print");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel4);
        jLabel4.setBounds(140, 0, 100, 40);

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 153, 51));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/edit.png"))); // NOI18N
        jLabel5.setText("Edit Result");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel5);
        jLabel5.setBounds(290, 0, 140, 40);

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 153, 51));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/save.png"))); // NOI18N
        jLabel6.setText("Save Result");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel6);
        jLabel6.setBounds(490, 0, 140, 40);

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 153, 51));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/add.png"))); // NOI18N
        jLabel7.setText("Add Record");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel7);
        jLabel7.setBounds(680, 0, 140, 40);

        add(jPanel2);
        jPanel2.setBounds(20, 10, 820, 50);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        add(jPanel3);
        jPanel3.setBounds(20, 130, 820, 300);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
       
       String fileName = NCalendar.getYear() + "_" + jComboBox1.getSelectedItem() + "_" + jComboBox2.getSelectedItem();
                        
       String directory = G3Splash.studentDir;
       File file = new File(directory + fileName + ".std");
        
       if(file.exists())
       {
           int age = 0;
           Object[] sqList = nFile.readAppend(file);
           Student[] allStudents = new Student[sqList.length];
           Object[] allStudStr = new Object[sqList.length];
           
           for(int c=0; c<sqList.length;c++)
           {
               String sList[] = sqList[c].toString().split("&");
               age = Integer.parseInt( sList[2].toString() );
               Student std = new Student(sList[0].toString(), sList[1].toString(), age, sList[3].toString(), sList[4].toString() );
               allStudents[c] = std;
               
               allStudStr[c] = sList[0].toString() + " | " + sList[1];
           }
           
           studList.showList( allStudStr );
           
           Object students[] = studList.getSelection().toArray();
       
            if(SList.selected){
                 if(students.length>0){
                addCells( students , 30, 5 );
                    }else{
                        new MsgBox().showMessage(null,"Student", "You did not select any student" );
                    }
                }else{
                    new MsgBox().showMessage(null, "Student",  "You canceled student selection" );
            }
       }else{
           new MsgBox().showMessage(null, "Result", "Please add students for " + fileName );
       }
       
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        clearCells();
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        teacher.printResult( resultArray );
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        String fileName = NCalendar.getYear() + "_" + jComboBox1.getSelectedItem() + "_" + jComboBox2.getSelectedItem() + "_" + jComboBox3.getSelectedItem();
        File file = new File(G3Splash.resultDir + fileName + ".rsl" );
        
        teacher.saveResult(resultArray, file );
    }//GEN-LAST:event_jLabel6MouseClicked

    
    ResultFileList resultFileList = new ResultFileList();
    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        
        String directory = G3Splash.resultDir;
        
        String[] list = new File(directory).list();
        if(list.length>0){
            resultFileList.showList( directory , list );
            
            String fName = "";
            
            try{
                fName = resultFileList.getSelection().toString();
            }catch(Exception e){}
       
            String fileName = "";
            if(fName !=null && fName.length()>4){ fileName = fName.substring(0, fName.length()-4); }
       
            if(ResultFileList.selected){
                
                if( user.hasPriviledge( fileName) ){
                if(!fileName.equals("")){
                    
                        File file = new File( G3Splash.resultDir + fileName + ".rsl" );
        
                        ArrayList<ECell> cells = teacher.updateResult(file);
                        updateEditCells( cells , 30, 5 );
                }
                }else{ new MsgBox().showMessage(null,"Priviledge",  "You dont have the priviledge to modify this result"); }
                
            }else{
                new MsgBox().showMessage(null,"Result Selection", "You canceled selection" );
            }
       
        }else{ new MsgBox().showMessage(null,"Save", "No result has been saved" ); }
       
    }//GEN-LAST:event_jLabel5MouseClicked

    
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    
    public static void removeCell(ECell cell)
    {
        resultArray.remove(cell);
        refreshCells(resultArray, 30, 5);
    }
    
    public void clearCells()
    {
        jPanel3.removeAll();
        resultArray.clear();
        jPanel3.updateUI();
        jLabel8.setText("0");
    }
    
    
    static ArrayList<ECell> resultArray = new ArrayList<ECell>();
    
    public void addCells( Object[] students , int elementLength, int spacing )
    {
        jPanel3.removeAll();
        resultArray.clear();
        
        int totalSize = students.length * elementLength + students.length * spacing;
        jLabel8.setText(students.length+"");
        
        for(int i=0; i<students.length; i++){
            
            ECell cell = new ECell( students[i].toString() , (i+1) );
            cell.setPreferredSize( new Dimension(980, elementLength));
            resultArray.add(cell);
            jPanel3.add(cell);
        }
        
        jPanel3.setPreferredSize( new Dimension( 980, totalSize) );
        jPanel3.updateUI();
    }
    
    
    public static void refreshCells( ArrayList<ECell> cells , int elementLength, int spacing )
    {
        jPanel3.removeAll();
        int totalSize = cells.size()*elementLength + cells.size()*spacing;
        jLabel8.setText(cells.size()+"");
        
        for(int i=0; i<cells.size(); i++){
            ECell cell = cells.get(i);
            jPanel3.add(cell); }
        
        jPanel3.setPreferredSize( new Dimension( 980, totalSize) );
        jPanel3.updateUI();
    }    
    
    
    public static void updateEditCells( ArrayList<ECell> cells ,int elementLength, int spacing )
    {
        jPanel3.removeAll();
        resultArray.clear();;
        
        int totalSize = cells.size()*elementLength + cells.size()*spacing;
        jLabel8.setText(cells.size()+"");
        
        for(int i=0; i<cells.size(); i++){
            
            ECell cell = cells.get(i);
            resultArray.add(cell);
            jPanel3.add(cell);
        }
        
        jPanel3.setPreferredSize( new Dimension( 980, totalSize) );
        jPanel3.updateUI();
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JComboBox jComboBox1;
    private static javax.swing.JComboBox jComboBox2;
    private static javax.swing.JComboBox jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private static javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private static javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
