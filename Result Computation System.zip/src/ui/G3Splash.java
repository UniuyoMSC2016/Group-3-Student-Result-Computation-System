package ui;


/**
 *
 * @author Ny
 */

import java.io.File;
import ui.Screen;
import javax.swing.*;
import services.CreatePGMFolder;


public class G3Splash extends javax.swing.JPanel {

    static JFrame frame = new JFrame("Splash");
    
    static String keyDir, studentDir, resultDir;
    
    public G3Splash() {
        initComponents();
        
        int x = Screen.width();
        int y = Screen.height();
        
        frame.setLocation((x/2) - (510/2), y/2-265/2);
        frame.add(this);
        //frame.setResizable(false);
        frame.setUndecorated(true);
	frame.setSize(510,264);
	frame.setVisible(true);
        
        new G3SplashSimulator(jProgressBar1, 500, 10, frame);
        
        Thread tr = new Thread()
        {
            public void run(){
                
                new CreatePGMFolder().makeDirectory("RESULT COMPUTATION SYSTEM");
        
                new CreatePGMFolder().makeDirectory("RESULT COMPUTATION SYSTEM" + File.separator + "Key");
                new CreatePGMFolder().makeDirectory("RESULT COMPUTATION SYSTEM" + File.separator + "Result");
                new CreatePGMFolder().makeDirectory("RESULT COMPUTATION SYSTEM" + File.separator + "Student");
        
                String doc = new CreatePGMFolder().getDefaultDirectory();
                keyDir = doc + File.separator + "RESULT COMPUTATION SYSTEM" + File.separator +  "Key" + File.separator;
                studentDir = doc + File.separator + "RESULT COMPUTATION SYSTEM" + File.separator + "Student" + File.separator;
                resultDir = doc + File.separator + "RESULT COMPUTATION SYSTEM" + File.separator + "Result" + File.separator;

        
               // System.out.println(keyDir);
        
        
            }
        };
        tr.start();
        
    }

    
    public static void main(String g[])
    {
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            	if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        
        new G3Splash();
        
        
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255), 2));
        setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 26)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Students Result Computation System");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(10, 10, 490, 40);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 255, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("for Secondary Schools");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(10, 47, 490, 30);

        add(jPanel2);
        jPanel2.setBounds(0, 0, 510, 90);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 153, 0));
        jLabel4.setText("This process will only take few seconds . . .");
        jLabel4.setToolTipText("");
        add(jLabel4);
        jLabel4.setBounds(30, 150, 450, 20);

        jProgressBar1.setStringPainted(true);
        add(jProgressBar1);
        jProgressBar1.setBounds(30, 190, 450, 20);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JProgressBar jProgressBar1;
    // End of variables declaration//GEN-END:variables
}
