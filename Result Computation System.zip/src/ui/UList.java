package ui;


/**
 *
 * @author Ny
 */

import ui.G3ListRenderer;
import ui.JFDragger;
import java.awt.Dialog;
import javax.swing.*;
import java.util.*;
import java.awt.Color;
import java.io.*;



public class UList extends javax.swing.JPanel {

    
    JDialog frame = new JDialog();
    public UList() {
        initComponents();
        
        frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        frame.setSize( 478, 532 );
        frame.add(this);
        frame.setUndecorated(true);
        frame.setLocationRelativeTo(null);
        
        
        jList2.setCellRenderer( new G3ListRenderer());
        jList2.setFixedCellHeight(35);
        jList2.setFixedCellWidth(260);
        
        new JFDragger(frame, jLabel1);
        
    }

    
    public void showList( Object[] list )
    {
        jList2.setListData(list);
        frame.setVisible(true);
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51), 2));
        setLayout(null);

        jScrollPane2.setBorder(null);

        jList2.setBackground(new java.awt.Color(255, 255, 255));
        jList2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jScrollPane2.setViewportView(jList2);

        add(jScrollPane2);
        jScrollPane2.setBounds(20, 120, 430, 390);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 204));
        jLabel1.setText("USER'S LIST");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
        add(jLabel1);
        jLabel1.setBounds(20, 0, 340, 80);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/del.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        add(jLabel2);
        jLabel2.setBounds(420, 20, 30, 30);

        jLabel4.setBackground(new java.awt.Color(0, 204, 204));
        jLabel4.setOpaque(true);
        add(jLabel4);
        jLabel4.setBounds(20, 60, 430, 2);

        jLabel5.setBackground(new java.awt.Color(245, 245, 245));
        jLabel5.setForeground(new java.awt.Color(255, 153, 51));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("NAME");
        jLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel5.setOpaque(true);
        add(jLabel5);
        jLabel5.setBounds(20, 80, 90, 30);

        jLabel6.setBackground(new java.awt.Color(245, 245, 245));
        jLabel6.setForeground(new java.awt.Color(255, 153, 51));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("ID");
        jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel6.setOpaque(true);
        add(jLabel6);
        jLabel6.setBounds(110, 80, 70, 30);

        jLabel7.setBackground(new java.awt.Color(245, 245, 245));
        jLabel7.setForeground(new java.awt.Color(255, 153, 51));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("USERNAME");
        jLabel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel7.setOpaque(true);
        add(jLabel7);
        jLabel7.setBounds(180, 80, 90, 30);

        jLabel8.setBackground(new java.awt.Color(245, 245, 245));
        jLabel8.setForeground(new java.awt.Color(255, 153, 51));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("PASSWORD");
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel8.setOpaque(true);
        add(jLabel8);
        jLabel8.setBounds(270, 80, 90, 30);

        jLabel9.setBackground(new java.awt.Color(245, 245, 245));
        jLabel9.setForeground(new java.awt.Color(255, 153, 51));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("PRIVILEDGE");
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jLabel9.setOpaque(true);
        add(jLabel9);
        jLabel9.setBounds(360, 80, 90, 30);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        frame.dispose();
       
    }//GEN-LAST:event_jLabel2MouseClicked

    static List list;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList1;
    private javax.swing.JList jList2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
