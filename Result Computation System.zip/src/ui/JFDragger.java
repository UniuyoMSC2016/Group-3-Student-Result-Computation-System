package ui;



import javax.swing.*;
import java.awt.event.*;

public class JFDragger
{

	int x = 0 , x2 = 0 , y = 0;
	int fx = 0, fy = 0;

	public JFDragger(final JFrame frame, JPanel DragPanel)
	{

		DragPanel.addMouseMotionListener
		(
			new MouseMotionAdapter()
			{
				public void mouseDragged(MouseEvent evt)
				{	
					
					x =  (evt.getXOnScreen() - fx);
					y = (evt.getYOnScreen() - fy);
					frame.setLocation(x,y);
											
				}
			}
		);


		DragPanel.addMouseListener
		(
			new MouseAdapter()
			{
				public void mousePressed(MouseEvent evp)
				{	
					fx =  (evp.getX());
					fy = (evp.getY());			
											
				}
			}
		);


		DragPanel.addMouseMotionListener
		(
			new MouseMotionAdapter()
			{
				public void mouseMoved(MouseEvent evt)
				{
					//System.out.println(" X = "+evt.getX() +" Y = "+evt.getY());
				}
			}
		);

	}//end of constructor

	public JFDragger(final JDialog frame, JLabel DragPanel)
	{

		DragPanel.addMouseMotionListener
		(
			new MouseMotionAdapter()
			{
				public void mouseDragged(MouseEvent evt)
				{	
					
					x =  (evt.getXOnScreen() - fx);
					y = (evt.getYOnScreen() - fy);
					frame.setLocation(x,y);
											
				}
			}
		);


		DragPanel.addMouseListener
		(
			new MouseAdapter()
			{
				public void mousePressed(MouseEvent evp)
				{	
					fx =  (evp.getX());
					fy = (evp.getY());			
											
				}
			}
		);


		DragPanel.addMouseMotionListener
		(
			new MouseMotionAdapter()
			{
				public void mouseMoved(MouseEvent evt)
				{
					//System.out.println(" X = "+evt.getX() +" Y = "+evt.getY());
				}
			}
		);

	}//end of constructor
        
        
        
        
        public JFDragger(final JFrame frame, JLabel DragPanel)
	{

		DragPanel.addMouseMotionListener
		(
			new MouseMotionAdapter()
			{
				public void mouseDragged(MouseEvent evt)
				{	
					
					x =  (evt.getXOnScreen() - fx);
					y = (evt.getYOnScreen() - fy);
					frame.setLocation(x,y);
											
				}
			}
		);


		DragPanel.addMouseListener
		(
			new MouseAdapter()
			{
				public void mousePressed(MouseEvent evp)
				{	
					fx =  (evp.getX());
					fy = (evp.getY());			
											
				}
			}
		);


		DragPanel.addMouseMotionListener
		(
			new MouseMotionAdapter()
			{
				public void mouseMoved(MouseEvent evt)
				{
					//System.out.println(" X = "+evt.getX() +" Y = "+evt.getY());
				}
			}
		);

	}//end of constructor





        
	public static void main(String arg[])
        {
		

	}

	
}
