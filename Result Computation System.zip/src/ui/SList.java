package ui;


/**
 *
 * @author Ny
 */

import ui.JFDragger;
import java.awt.Dialog;
import javax.swing.*;
import java.util.*;
import java.awt.Color;
import java.io.*;



public class SList extends javax.swing.JPanel {

    /**
     * Creates new form SList
     */
    
    JDialog frame = new JDialog();
    public SList() {
        initComponents();
        
        frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        frame.setSize( 478, 532 );
        //frame.setDefaultCloseOperation(3);
        frame.add(this);
        frame.setUndecorated(true);
        frame.setLocationRelativeTo(null);
        
        
        jList2.setCellRenderer( new G3ListRenderer());
        jList2.setFixedCellHeight(35);
        jList2.setFixedCellWidth(260);
        
        new JFDragger(frame, jLabel1);
        
    }

    
    public void showList( Object[] list )
    {
        jList2.setListData(list);
        frame.setVisible(true);
    }
    
    
    static boolean selected = false;
    public List getSelection()
    {
        List item = null;
        try{
            item = jList2.getSelectedValuesList();
        }catch(Exception e){}
        
        return item;
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51), 2));
        setLayout(null);

        jScrollPane2.setBorder(null);

        jList2.setBackground(new java.awt.Color(255, 255, 255));
        jList2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jList2.setForeground(new java.awt.Color(0, 153, 153));
        jList2.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "EKEMINI", "NY", "EDIDIONG", "OKON", "IYKE", "TUNJI", "NANCY", "THURSDAY", "PHILIP", "EMEKA", "ISRAEL" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jList2);

        add(jScrollPane2);
        jScrollPane2.setBounds(20, 80, 430, 430);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 204));
        jLabel1.setText("STUDENT LIST");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
        add(jLabel1);
        jLabel1.setBounds(20, 0, 250, 80);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        add(jLabel2);
        jLabel2.setBounds(360, 20, 0, 30);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        add(jLabel3);
        jLabel3.setBounds(420, 20, 0, 30);

        jLabel4.setBackground(new java.awt.Color(0, 204, 204));
        jLabel4.setOpaque(true);
        add(jLabel4);
        jLabel4.setBounds(20, 60, 430, 2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/del.png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        add(jLabel5);
        jLabel5.setBounds(310, 20, 60, 30);

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/pick.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        add(jLabel6);
        jLabel6.setBounds(390, 20, 60, 30);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jLabel2MouseClicked

    static List list;
    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // TODO add your handling code here:
         frame.dispose();
        selected = false;
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
         frame.dispose();
        selected = true;
        list = jList2.getSelectedValuesList();
    }//GEN-LAST:event_jLabel6MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JList jList1;
    private javax.swing.JList jList2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
