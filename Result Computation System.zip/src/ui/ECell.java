package ui;


/**
 *
 * @author Ny
 */

import services.Teacher;
import java.awt.Color;
import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.*;

public class ECell extends javax.swing.JPanel {

    
    Teacher teacher = new Teacher("", "", "", "");
    
    public ECell(String name , int serial  ) {
        initComponents();
        
        jTextField1.setText(name);
        jTextField1.setEditable(false);
        
        jLabel2.setText( serial+"" );
        
        jFormattedTextField1.addKeyListener( new G3KeyEvent() );
        jFormattedTextField2.addKeyListener( new G3KeyEvent() );
        jFormattedTextField3.addKeyListener( new G3KeyEvent() );
        
        jFormattedTextField4.addKeyListener( new G3ExmKeyEvent() );
    }
    
    
    public ECell(String name , String t1, String t2, String t3, String exm, String ca, String total, String grade, int serial  ) {
        initComponents();
        
        jTextField1.setText(name);
        jTextField1.setEditable(false);
        jLabel2.setText( serial+"" );
        
        
        jFormattedTextField1.addKeyListener( new G3KeyEvent() );
        jFormattedTextField2.addKeyListener( new G3KeyEvent() );
        jFormattedTextField3.addKeyListener( new G3KeyEvent() );
        jFormattedTextField4.addKeyListener( new G3ExmKeyEvent() );
        
        jTextField1.setText(name);
        jFormattedTextField1.setText(t1);
        jFormattedTextField2.setText(t2);
        jFormattedTextField3.setText(t3);
        jFormattedTextField4.setText(exm);
        
        jTextField6.setText(ca);
        jTextField7.setText(total);
        jTextField8.setText(grade);
        
        
        
    }
    
    
    public String getCA()
    {
        String ca = (jTextField6.getText().trim().equals(""))? "0" : jTextField6.getText();
        return ca;
    }
    
    public String getExams()
    {
        String exm = (jFormattedTextField4.getText().trim().equals(""))? "0" : jFormattedTextField4.getText();
        return exm;
    }
    
    public String getGrade()
    {
       String grd = (jTextField8.getText().trim().equals(""))? "0" : jTextField8.getText(); 
       return grd;
    }
    
    public String getTest1()
    {
        String t1 = (jFormattedTextField1.getText().trim().equals(""))? "0" : jFormattedTextField1.getText();
        return t1;
    }
    public String getTest2()
    {
        String t2 = (jFormattedTextField2.getText().trim().equals(""))? "0" : jFormattedTextField2.getText();
        return t2;
    }
    public String getTest3()
    {
        String t3 = (jFormattedTextField3.getText().trim().equals(""))? "0" : jFormattedTextField3.getText();
        return t3;
    }
    
    
    public String getStudentName()
    {
        String nm = (jTextField1.getText().trim().equals(""))? "***" : jTextField1.getText();
        return nm;
    }
    
    public String getTotal()
    {
        String tt = (jTextField7.getText().trim().equals(""))? "0" : jTextField7.getText();
        return tt;
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jFormattedTextField2 = new javax.swing.JFormattedTextField();
        jFormattedTextField3 = new javax.swing.JFormattedTextField();
        jFormattedTextField4 = new javax.swing.JFormattedTextField();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(1050, 38));
        setLayout(null);

        jLabel1.setBackground(new java.awt.Color(235, 235, 235));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/raw/del.png"))); // NOI18N
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        add(jLabel1);
        jLabel1.setBounds(0, 0, 30, 30);

        jTextField1.setBackground(new java.awt.Color(244, 244, 244));
        jTextField1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        add(jTextField1);
        jTextField1.setBounds(30, 0, 240, 30);

        jTextField6.setEditable(false);
        jTextField6.setBackground(new java.awt.Color(244, 244, 244));
        jTextField6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jTextField6.setForeground(new java.awt.Color(0, 0, 0));
        jTextField6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        add(jTextField6);
        jTextField6.setBounds(570, 0, 120, 30);

        jTextField7.setEditable(false);
        jTextField7.setBackground(new java.awt.Color(244, 244, 244));
        jTextField7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jTextField7.setForeground(new java.awt.Color(0, 0, 0));
        jTextField7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        add(jTextField7);
        jTextField7.setBounds(690, 0, 110, 30);

        jTextField8.setEditable(false);
        jTextField8.setBackground(new java.awt.Color(244, 244, 244));
        jTextField8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jTextField8.setForeground(new java.awt.Color(0, 0, 0));
        jTextField8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        add(jTextField8);
        jTextField8.setBounds(800, 0, 140, 30);

        jLabel2.setBackground(new java.awt.Color(210, 210, 210));
        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 102, 0));
        add(jLabel2);
        jLabel2.setBounds(940, 0, 40, 30);

        jFormattedTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jFormattedTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jFormattedTextField1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("0.0"))));
        jFormattedTextField1.setCaretColor(new java.awt.Color(0, 255, 204));
        jFormattedTextField1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        add(jFormattedTextField1);
        jFormattedTextField1.setBounds(270, 0, 70, 30);

        jFormattedTextField2.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextField2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jFormattedTextField2.setForeground(new java.awt.Color(0, 0, 0));
        jFormattedTextField2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("0.0"))));
        jFormattedTextField2.setCaretColor(new java.awt.Color(0, 255, 204));
        jFormattedTextField2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jFormattedTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextField2ActionPerformed(evt);
            }
        });
        add(jFormattedTextField2);
        jFormattedTextField2.setBounds(340, 0, 70, 30);

        jFormattedTextField3.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextField3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jFormattedTextField3.setForeground(new java.awt.Color(0, 0, 0));
        jFormattedTextField3.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("0.0"))));
        jFormattedTextField3.setCaretColor(new java.awt.Color(0, 255, 204));
        jFormattedTextField3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        add(jFormattedTextField3);
        jFormattedTextField3.setBounds(410, 0, 70, 30);

        jFormattedTextField4.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextField4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 210, 210)));
        jFormattedTextField4.setForeground(new java.awt.Color(0, 0, 0));
        jFormattedTextField4.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("0"))));
        jFormattedTextField4.setCaretColor(new java.awt.Color(0, 255, 204));
        jFormattedTextField4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        add(jFormattedTextField4);
        jFormattedTextField4.setBounds(480, 0, 90, 30);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jFormattedTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextField2ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        ComputeResultUI.removeCell( ECell.this );
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    
    private class G3KeyEvent implements KeyListener
    {
        @Override
          public void keyReleased(KeyEvent t){
              double test1 = 0.0, test2 = 0.0, test3 = 0.0, exm = 0.0;
              JFormattedTextField txtF = (JFormattedTextField)t.getSource();
              
              String t1Txt = (jFormattedTextField1.getText().equals(""))? "0" : jFormattedTextField1.getText();
              String t2Txt = (jFormattedTextField2.getText().equals(""))? "0" : jFormattedTextField2.getText();
              String t3Txt = (jFormattedTextField3.getText().equals(""))? "0" : jFormattedTextField3.getText();
              
              String exmTxt = (jFormattedTextField4.getText().equals(""))? "0" : jFormattedTextField4.getText();
              try{
                  flagError( txtF , Double.parseDouble(txtF.getText()) , 10 );
                  
                  test1 = Double.parseDouble( t1Txt );
                  test2 = Double.parseDouble( t2Txt);
                  test3 = Double.parseDouble( t3Txt );
                  
                  exm = Double.parseDouble(exmTxt );
                  
                  
              }catch(Exception e){}
              
              //JOptionPane.showMessageDialog(null, t2Txt );
              double ca = teacher.calculateCA( test1, test2, test3);
              jTextField6.setText(ca+"");
              
              double total = ca + exm;
              String grade = teacher.computeGrade( total );
              jTextField7.setText( total+"" );
              jTextField8.setText( grade );
             // teacher.computeGrade(ca);
        
          }
          
        @Override
          public void keyPressed(KeyEvent t){ }
          
        @Override
          public void keyTyped(KeyEvent t){ }
          
    }
    
    
    
    private class G3ExmKeyEvent implements KeyListener
    {
        @Override
          public void keyReleased(KeyEvent t){
              double ca = 0.0, exm = 0.0;
              JFormattedTextField txtExm = (JFormattedTextField)t.getSource();
              String exmTxt = (jFormattedTextField4.getText().equals(""))? "0" : jFormattedTextField4.getText();
              
              try{
                  flagExmError( txtExm , Double.parseDouble(txtExm.getText()) , 70 );
                  
                  exm = Double.parseDouble(exmTxt);
                  ca = Double.parseDouble(jTextField6.getText());
                  
              }catch(Exception e){}
              
              double total = ca + exm;
              String grade = teacher.computeGrade( total );
              jTextField7.setText( total+"" );
              jTextField8.setText( grade );
          }
          
        @Override
          public void keyPressed(KeyEvent t){ }
          
        @Override
          public void keyTyped(KeyEvent t){ }
          
    }
    
    
    public void flagError(JComponent c, double value, double boundary)
    {
        if(value>boundary){
            c.setBackground(Color.orange);
        }else{
            c.setBackground( new Color(255,255,255) );
        }
    }

    
    public void flagExmError(JComponent c, double value, double boundary)
    {
        if(value>boundary){
            c.setBackground(Color.orange);
        }else{
            c.setBackground(new Color(255,255,255));
        }
    }

    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JFormattedTextField jFormattedTextField2;
    private javax.swing.JFormattedTextField jFormattedTextField3;
    private javax.swing.JFormattedTextField jFormattedTextField4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables
}
